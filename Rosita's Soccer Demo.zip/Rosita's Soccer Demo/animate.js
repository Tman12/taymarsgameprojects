﻿/*
Ashley Delvento
7/31/2019 Copy
Rosita Soccer Practice
*/

//Temporary Stagnent Level Number
var level = 1;
//buttonID Counter
let buttonIdCounter = 5;

//On Load functions
function atStart(){
	levelManager(level);
	hideUnusedDestinations();
	hideUnIntroedMoves();
	drawStreet();
	moveNet();
	init();
	ballPos = 195;
}
var ballPos = 195;
var ballDes;
//initializing button click to sync id
function moveClicked(id){
	animate(id);
}

//Creates an array to determine which sequence destinations are filled
var destinationFilled = []; var numeroDestin = 6;
for(var i = 1; i < numeroDestin; i++){
	destinationFilled[i] = false;
}

//Function that returns whether or not the particular button is in the sequenceTray
function inSeq(buttonId){
	let x = buttonId;
	return document.getElementById(x).value;
}

//Creates an array that stores the order of the moves in the sequence
var playSequence = []; var Moves = 5;
for(var i = 0; i < Moves; i++){
	playSequence[i] = "";
}

//hides destination squares that are not requeired in the soluction
function hideUnusedDestinations(){
	document.getElementById("destin01").style.visibility = 'visible';
	for(var i = (correctSequence.length + 1); i < 6; i++){
		document.getElementById("destin0" + i).style.visibility = 'hidden';
	}
}

//Reset all destinations to visible
function resetElementDestinations(){
	for(var i = 1; i < numeroDestin; i++){
		document.getElementById("destin0" + i).style.visibility = 'visible';
	}
}

//keeps original button placement in elements tray
function elemTrayPlace(cl){
	var x = cl;
	if(x == 'run'){
		return 55;
	} else if(x == 'kick'){
		return 135;
	} else if(x == 'jump'){
		return 215;
	} else if(x == 'slide'){
		return 295;
	} else {alert("error: elemTrayPlace function");}
}

//Resetting destination as empty once a button leaves
function emptyDestination(buttonId){
	var y = buttonId;
	var elem = document.getElementById(y);
	if(inSeq(y) == "true"){
	if(elem.style.left == '183px'){
		destinationFilled[1] = false;
		playSequence[1] = "";
	} else if(elem.style.left == '293px'){
		destinationFilled[2] = false;
		playSequence[2] = "";
	}else if(elem.style.left == '403px'){
		destinationFilled[3] = false;
		playSequence[3] = "";
	}else if(elem.style.left == '513px'){
		destinationFilled[4] = false;
		playSequence[4] = "";
	}else if(elem.style.left == '623px'){
		destinationFilled[5] = false;
		playSequence[5] = "";
	}else {alert("error: emptyDestination function");}
}
}

//creates a new button once one of that class has been used
function createButton(cl){
	let test = cl;
	let newButton = document.createElement('addedButton');
	let newButtonVal = false;
	let sourceim = getSrc(cl);
	newButton.innerHTML=`<input type='image' id='button0${buttonIdCounter}'  value='${newButtonVal}'  class='${test}' onClick = 'moveClicked(this.id, this.class)' src='${sourceim}'></input>`;
	document.getElementById('myContainer').appendChild(newButton);
	buttonIdCounter++;
}

//deletes a button from the sequenceTray
function deleteButton(id) {
	let buttonId = id;
	let elem = document.getElementById(buttonId);
	//var anim=setInterval(reset,6);
	emptyDestination(buttonId);
	elem.parentNode.removeChild(elem);
}

//Converts type back to buttonId
function typeToButton(type){
	var x = type;
	if(x == "run"){
		return "button01";
	} else if(x == "kick"){
		return "button02";
	} else if(x == "jump"){
		return "button03";
	} else if(x == "slide"){
		return "button04";
	} else {alert("error: typeToButton function");}
}

//hides unintroduced moves from the player
function hideUnIntroedMoves(){
	document.getElementsByClassName('run')[0].style.visibility = 'visible';
	for(var i = (numberMovesIntroed + 1); i<5; i++){
		if(i == 2){
			document.getElementsByClassName('kick')[0].style.visibility = 'hidden';
			document.getElementsByClassName('kick')[0].disabled = true;
		} else if (i == 3){
			document.getElementsByClassName('jump')[0].style.visibility = 'hidden';
			document.getElementsByClassName('jump')[0].disabled = true;
		} else if (i == 4){
			document.getElementsByClassName('slide')[0].style.visibility = 'hidden';
			document.getElementsByClassName('slide')[0].disabled = true;
		}else{alert("error: hideUnIntroedMoves function");}
	}
}

//introduce new moves and highlight them for the duration of the explination line
function introNewMoves(){
	let elemtemp;
	let clss;
	for(var i = numberMovesIntroed; i > 0; i--){
		if(i == 1){
		elemtemp = document.getElementsByClassName('run');
		clss = 'run';
	} else if (i == 2){
		elemtemp = document.getElementsByClassName('kick');
		clss = 'kick';
	} else if (i == 3){
		elemtemp = document.getElementsByClassName('jump');
		clss = 'jump';
	}else if (i == 4){
		elemtemp = document.getElementsByClassName('slide');
		clss = 'slide';
	} else{alert("error: introNewMoves function");}
		elemtemp[0].style.visibility = 'visible';
		elemtemp[0].disabled = false;
	}
	//highlights the first instance of a move the first time it appears for the duration of an intro line
	var originalcolor = getOriginalColor(clss);
	alert("<Insert Rosita move intro VO>");
	var lengthofVoiceOver = 4000;
	elemtemp[0].style.setProperty('border-color', '#072AFC');
	setTimeout(function(){elemtemp[0].style.setProperty('border-color', originalcolor);}, lengthofVoiceOver);
}

//gets the original color of the button based on the type of button it inspect
//Might remove in the future and just make all buttons the same color, but the idea is to aid in highlighting a new function
function getOriginalColor(cl){
	let x = cl;
	if(x == 'run'){
		return '#81e0f7';
	} else if (x == 'kick'){
		return '#f58d78';
	} else if (x == 'jump'){
		return '#be8cea';
	} else if (x == 'slide'){
		return '#a6e357';
	} else {alert("error: getOriginalColor function");}
}

//returns source icon when given a buttons class
function getSrc(cl){
	let test = cl;
	if(test == 'run'){
		return "walk_icon_temp.png";
	} else if (test == 'kick'){
		return "kick_icon_temp.png";
	} else if (test == 'jump'){
		return "jump_icon_temp.png";
	} else if (test == 'slide'){
		return "slide_icon_temp.png";
	} else {alert("error: getSrc function");}
}

//Disables all buttons - called when one button begins animating
function disableButtons(){
		let inputs = document.querySelectorAll('input.run');
		inputs.forEach(input => input.disabled = true);
		inputs = document.querySelectorAll('input.kick');
		inputs.forEach(input => input.disabled = true);
		inputs = document.querySelectorAll('input.jump');
		inputs.forEach(input => input.disabled = true);
		inputs = document.querySelectorAll('input.slide');
		inputs.forEach(input => input.disabled = true);
	document.getElementById("playbutton").disabled = true;
}

//Enables all buttons - called when the button is finished animating
function enableButtons(){
	let inputs = document.querySelectorAll('input.run');
	inputs.forEach(input => input.disabled = false);
	inputs = document.querySelectorAll('input.kick');
	inputs.forEach(input => input.disabled = false);
	inputs = document.querySelectorAll('input.jump');
	inputs.forEach(input => input.disabled = false);
	inputs = document.querySelectorAll('input.slide');
	inputs.forEach(input => input.disabled = false);
document.getElementById("playbutton").disabled = false;
}

//creates counter and dimensions for obstacles
let obsCounter = 1;
let dimensionw;
let dimensionh;
let dimensiont;
var placement;
var obsticarray = [];
//Creates obstacles based on the correctSequence for the current level
function createObstacle(test, placement){
	let x = test;
	let z = placement;
	let newObs = document.createElement('addedObstacle');
	let sourceim;
	let identi = "obstacle0" + obsCounter;
	obsticarray.push(identi);
	if(x == 'jump'){
		sourceim = selectJumpObstacle();
	} else if (x == 'slide'){
		sourceim = selectSlideObstacle();
	} else {alert("error: createObstacle function");}
	newObs.innerHTML = `<image id='${identi}' class ='obstacle' src='${sourceim}'> </image>`;
	document.getElementById('myContainer').appendChild(newObs);
	document.getElementById(identi).style.width = dimensionw + 'px';
	document.getElementById(identi).style.height = dimensionh + 'px';
	document.getElementById(identi).style.top = dimensiont + 'px';
	document.getElementById(identi).style.left = getLocationInSeq(z) + 'px';
	obsCounter++;
}

//translates location in correctSequence array to a location on the gamescreen
function getLocationInSeq(z){
	var place = z;
	if(place == 1){
		return 275;
	} else if(place == 2){
		return 367;
	} else if(place == 3){
		return 510;
	} else if(place == 4){
		return 600;
	}
	 else {alert("error: getLocationInSeq function");}
}

//randomly selects an obstacle for the slide move
let numberOfSlideObstacles = 2;
function selectSlideObstacle(){
	let x = Math.floor(Math.random() * numberOfSlideObstacles) + 1;
	if(x === 1){
		dimensiont = 290;
		dimensionw = 28;
		dimensionh = 171;
		return "Rosita_parking_meter.png";
	}
	else if(x === 2){
		dimensiont = 300;
		dimensionw = 131;
		dimensionh = 171;
		return "Rosita_restaurant_sign.png";
	}
	else{alert("error: selectSlideObstacle function")}
}

//randomly selects an obstacle for the jump move
let numberOfJumpObstacles = 5;
function selectJumpObstacle(){
	let x = Math.floor(Math.random() * numberOfJumpObstacles) + 1;
	if(x === 1){
		dimensiont = 390;
		dimensionw = 112;
		dimensionh = 77;
		return "Rosita_bush_1.png";
	}else if(x === 2){
		dimensiont = 390;
		dimensionw = 50;
		dimensionh = 80;
		return "Rosita_flowerpot_1.png";
	}else if(x === 3){
		dimensiont = 392;
		dimensionw = 131;
		dimensionh = 78;
		return "Rosita_laundry_basket.png";
	}else if(x === 4){
		dimensiont = 390;
		dimensionw = 74;
		dimensionh = 82;
		return "Rosita_pidgeon.png";
	}else if(x === 5){
		dimensiont = 387;
		dimensionw = 70;
		dimensionh = 85;
		return "Rosita_trash_can.png";
	}else{alert("error: selectJumpObstacle functions");}
}

//deletes obstacles from past level before new ones are loaded in
function deleteObstacles(){
	while(obsticarray.length > 0){
		var elem = document.getElementById(obsticarray[obsticarray.length - 1]);
		obsticarray.pop();
		elem.parentNode.removeChild(elem);
	}
	//let images = document.querySelectorAll('image.obstacle');
	//images.forEach(image => image.parentNode.removeChild(image));
}

//Moves the soccer net to the distance away based on correct sequence length
function moveNet(){
	if(level == 1){
		document.getElementById("net").style.visibility = 'hidden';
	}else{
		document.getElementById("net").style.visibility = 'visible';
		var netlocation = 275 + (102 * correctSequence.length);
		document.getElementById("net").style.left = netlocation + 'px';
	}
}
function moveBall(){
	var ball = document.getElementById("ball");
	ballPos = 195;
	var id = setInterval(frame, 11);
	function frame() {
	    if (ballPos == ballDes) {
	      clearInterval(id);
	    } else {
	      ballPos++;
	      ball.style.left = ballPos + "px";
	    }
	 }
}
//Animates the element into and from the sequence tray
function animate(id){
		var buttonId = id;
		var cl = document.getElementById(buttonId).className;
		var sz = 65;
		var elem = document.getElementById(buttonId);
		var positionLeft = elem.offsetLeft;
		var positionTop = elem.offsetTop;
		var ht = document.getElementById(buttonId).offsetHeight;
		var destht = 85;
		//Determines type of animation
		if(inSeq(buttonId) == "true"){
					deleteButton(id);
				} else{
					// Determines destination
					var dest = document.getElementById("destin01");
					for (var i = 1; i < destinationFilled.length; i++) {
        					if(!destinationFilled[i]) {
            						dest = document.getElementById("destin0" + i);
            						var destpositionLeft = dest.offsetLeft + 3;
            						var destpositionTop = dest.offsetTop + 3;
												var tomoveLeft = destpositionLeft - positionLeft;
												var tomoveTop = destpositionTop - positionTop;
												var degree = tomoveLeft/tomoveTop;
												break;
        					}
   					 }
					if(dest.style.visibility == 'visible'){
						destinationFilled[i] = true;
						playSequence[i] = document.getElementById(buttonId).className;
						var anim=setInterval(toDestination,4);
					}

				}

		//Activates movement animation to destination
		function toDestination(){
			if(positionTop == destpositionTop){
				enableButtons();
				document.getElementById(buttonId).value = "true";
				createButton(cl);
				clearInterval(anim);
			} else {
				disableButtons();
						if(positionLeft == destpositionLeft){
							elem.style.left = positionLeft + 'px';
						}else{
							positionLeft = positionLeft + (1 * degree);
							elem.style.left = positionLeft + 'px';
						}
				if(positionTop == destpositionTop){
						elem.style.top = positionTop + 'px';
				}else{
						positionTop++;
						elem.style.top = positionTop + 'px';
					}
					if(ht != destht){
						ht++;
						elem.style.height = ht + 'px';
						elem.style.width = ht + 'px';
					}
				}
		}

		//Activates reset animation -- triggering this animation sends errors when deleting this buttons
		//therefore this function is currently not in use and will be fixed at the end since it is cosmetic
		function reset(){
			if (sz == 10){
				enableButtons();
				document.getElementById(buttonId).value = false;
				clearInterval(anim);
			}else{
				emptyDestination(buttonId);
				disableButtons();
				sz--;
				elem.style.width = sz + 'px';
				elem.style.height = (sz + 5) + 'px';
			}
		}
}

//Play Button Control variables
var correctSequence = []; var correctMax = 5;
var altcorrectSequence = [];
var numberMovesIntroed = 1;
var newMoveIntroLvl = false;
var lockedinAns = 0;

//Plays the sequence of moves in the playsequence array
function startSequence(){
	var finalSeq = [];
	var index = 0;
	var animationLength = 0;
	for(var i = 0; i< playSequence.length; i++){
		if(playSequence[i] != ""){
			finalSeq[index] = playSequence[i];
			index++;
		}
	}

	//Alert statements are current filler for animation functions that are curretly being added
	for(var i = lockedinAns; i < finalSeq.length; i++){
		if((finalSeq[i] == correctSequence[i]) || (finalSeq[i] == altcorrectSequence[i])){
			if(finalSeq[i] == "run"){
				//alert("player runs");
				numFrames = 8;
				moveBall();
				//call init and change number variable
				init();
				lockedinAns++;
				animationLength++;
			} else if(finalSeq[i] == "kick"){
			//	alert("player kicks);
				numFrames = 7;
				lockedinAns++;
				animationLength++;
				moveBall();
			} else if(finalSeq[i] == "jump"){
				//alert("player jumps");
				numFrames = 11;
				lockedinAns++;
				animationLength++;
				moveBall();
			} else if (finalSeq[i] == "slide"){
			//	alert("player slides");
				numFrames = 9;
				lockedinAns++;
				animationLength++;
				moveBall();
			} else {
				alert("error: startSequence");
			}
		} else {
			alert("Wrong answer");
			while (i < finalSeq.length){
				animate(typeToButton(finalSeq[i]), finalSeq[i]);
				i++;
			}
		}
	}
	//checks if the sequence that has completed is correct and if so, moves the player onto the next level
	setTimeout(function () {
		if((lockedinAns == correctSequence.length) && ((finalSeq.length == correctSequence.length) || (finalSeq.length == altcorrectSequence.length)) && ((finalSeq[finalSeq.length - 1] == correctSequence[correctSequence.length - 1]) || (finalSeq[finalSeq.length - 1] == altcorrectSequence[altcorrectSequence.length - 1]))){
			alert("You have successfully completed the level!");
			newLevelStart();
		}
	}, (animationLength * 2000));
}

//Manages the level's correct answer and number of attributes featured
function levelManager(level){
	placement = 1;
	var lvl = level;
	var correctAnswerLength = 1;
	for(var i = 0; i < correctMax; i++){
		correctSequence[i] = "";
		altcorrectSequence[i] = "";
	}
	if(lvl == 1){
		correctSequence[0] = "run";
		altcorrectSequence[0] = "run";
		ballDes = 295; ballPos=295;
	}else if(lvl == 2){
		correctSequence[0] = "run"; correctSequence[1] = "kick";
		altcorrectSequence[0] = "run"; altcorrectSequence[1] = "kick";
		numberMovesIntroed++;
		newMoveIntroLvl = true;
		ballDes = 595; ballPos=300;
	}else if(lvl == 3){
		correctSequence[0] = "run"; correctSequence[1] = "jump"; correctSequence[2] = "kick";
		altcorrectSequence[0] = "jump"; altcorrectSequence[1] = "jump"; altcorrectSequence[2] = "kick";
		numberMovesIntroed++;
		newMoveIntroLvl = true;
		ballDes = 695; ballPos=300;
	}else if(lvl == 4){
		correctSequence[0] = "run"; correctSequence[1] = "slide"; correctSequence[2] = "kick";
		altcorrectSequence[0] = "slide"; altcorrectSequence[1] = "slide"; altcorrectSequence[2] = "kick";
		numberMovesIntroed++;
		newMoveIntroLvl = true;
		ballDes = 695; ballPos=295;
	}else if(lvl == 5){
		correctSequence[0] = "slide"; correctSequence[1] = "run"; correctSequence[2] = "jump"; correctSequence[3] = "run"; correctSequence[4] = "kick";
		altcorrectSequence[0] = "slide"; altcorrectSequence[1] = "slide"; altcorrectSequence[2] = "jump"; altcorrectSequence[3] = "jump"; altcorrectSequence[4] = "kick";
		newMoveIntroLvl = false;
		ballDes = 895; ballPos=295;
	}else if(lvl == 6){
		//Call the final celebration VO and then the replay overlay screen with replay VO
		alert("You have completed/won the game");
	}else {
		alert("error: levelManager");
	}
	for(var i = 1; i < correctSequence.length; i++){
		if(correctSequence[i] != ""){
			correctAnswerLength++;
		}
	}
	correctSequence.length = correctAnswerLength;
	altcorrectSequence.length = correctAnswerLength;
	for(var i = 0; i < correctSequence.length; i++){
		let test = correctSequence[i];
		if(test == 'jump' || test == 'slide'){
			createObstacle(test, placement);
		}
			placement++;
	}
}

//Resets elements when a new level is started (buttons and correct sequence and destinations shown)
function newLevelStart(){
	let inputs = document.querySelectorAll('input.run');
	inputs.forEach(input => input.remove());
	createButton('run');
	inputs = document.querySelectorAll('input.kick');
	inputs.forEach(input => input.remove());
	createButton('kick');
	inputs = document.querySelectorAll('input.jump');
	inputs.forEach(input => input.remove());
	createButton('jump');
	inputs = document.querySelectorAll('input.slide');
	inputs.forEach(input => input.remove());
	createButton('slide');
	for(var i = 1; i < numeroDestin; i++){
		destinationFilled[i] = false;
		playSequence[i] = "";
	}
	level++;
	lockedinAns = 0;
	correctSequence.length = correctMax;
	altcorrectSequence.length = correctMax;
	deleteObstacles();
	levelManager(level);
	resetElementDestinations();
	hideUnIntroedMoves();
	hideUnusedDestinations();
	moveNet();

	if(newMoveIntroLvl == true){
			introNewMoves();
	}

}
//End of Ashley Delvento Section


//Start of Michaela's Animation Section
//reference: https://atomicrobotdesign.com/blog/web-development/more-advanced-html5-canvas-sprite-sheet-walk-cycle-animation/

var canvas = document.getElementById("canvas"), // get our canvas tag in the DOM
    ctx = canvas.getContext('2d'), // set the context of the canvas
    character = new Image(), // create a new image object for our sprite sheet
    player = { // create our player object
      x: 30, // set the player’s x position
      y: 250, // set the player’s y position
      w: 250, // set the player’s width
      h: 250, // set the player’s height
      sx: 0, // set the player’s image’s source x position
      sy: 250, // set the player’s image’s source y position
      faceRight: true, // this will tell the code our player is facing right to start
      faceLeft: false, // this is set to false so our player will face right
      counter: 0, // counter we use to know when to change frames
      step: 12, // we change frames every 15 frames, so increase or decrease this number if you want the player to walk faster or slower
      nextStep: 0, // this increases with each frame change
      endStep: 96, // when counter equals this number, everything resets and we go back to the first frame
      start: { // sets the start postions of our source
        rightX: 0, // start x position when facing right
        leftX: 250, // start x position when facing left
        y: 250 // start y position is the same for both
      }
    },
    key = { // the variables we’ll use to see if a key is being pressed
      right: false,
      left: false
    };

//Introduce global variables
var numFrames = 0;
var count = 1;

/* 	function called by drawPlayer function
		parameters:
			numFrames: number of frames in a given action *
			right: do not worry about this one - variable used in case player ever needs to face oppposite direction
			left: same as right
			* (kick is numFrames = 7, walk is 8, slide is 9, and jump is 11)
		purpose: initiates one full cycle of a given move's animation
*/
function move(numFrames, right, left) {
  player.faceRight = right;
  player.faceLeft = left;
	if(numFrames == 0){
		return;
	}
  if (player.counter === player.endStep) { //?
		player.sx = 0;
		player.nextStep += 0;
		return;
	}
	else{
  	if (player.counter === player.nextStep) {
	    if (player.sx !== ((numFrames-1) * player.w)) {
	      player.sx += player.w;
	    }
	    //player.sy = yPos;
	    player.nextStep += player.step;
	  }
		else if (player.counter === 0){
	    player.sx += player.w;
	    player.nextStep += player.step;
	  }
		//alert(player.sx + "/" + player.w + ": " + (player.sx/player.w));
		if (numFrames != 7 &&
				!((numFrames == 11) &&
					!((player.sx/player.w) == 5 ||
					 (player.sx/player.w) == 6 ||
					 (player.sx/player.w) == 7 ||
					 (player.sx/player.w) == 8
					)
				 )
			 ){
			player.x += 1;
		}
	}
  player.counter += 1;
}

//purpose: reset the player for another move/action
function reset() {
  //player.sy = player.start.y;
  player.counter = 0;
  player.nextStep = 0;
}

/* 	function called by loop function; calls move function
		purpose: sets player up to perform required action; calls move to initiate action; moves player forward when appropriate
*/
function drawPlayer() {
	if (numFrames == 7){
		player.sy = 0;
	}
	else if (numFrames == 8){
		player.sy = 250;
	}
	else if (numFrames == 9){
		player.sy = 500;
	}
	else if (numFrames == 11){
		player.sy = 750;
	}
	else if (numFrames == 0){
		//causes the error function not to fire on initial load
	}
	else{
		alert("Error: invalid value for numFrames.")
		return;
	}
  move(numFrames, true, false);
  if (player.x > canvas.width + player.w + 1) {
    player.x = -player.w;
  }
	ctx.drawImage(character, player.sx, player.sy, player.w, player.h, player.x, player.y, player.w, player.h);
	count++;
}


//purpose: clear canvas (sorry to state the obvious, it's just consistent)
function clearCanvas() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}

/* 	function called by atStart function
		purpose: draw Street for the first time
*/
function drawStreet(){
	var canvas = document.getElementById("canvas");
	var context = canvas.getContext('2d');
	var streetImage = new Image();
	streetImage.onload = function(){
		context.drawImage(streetImage, 98, -75, 1122, 585);
	}
	streetImage.src = 'RSPAssets_StreetScene1_NoChars.png';
}

/* 	function called by loop function
		purpose: draw Street after the first time
*/
function drawBG() {
	var canvas = document.getElementById("canvas");
	var context = canvas.getContext('2d');
	var streetImage = new Image();
	streetImage.src = 'RSPAssets_StreetScene1_NoChars.png';
	context.drawImage(streetImage, 98, -75, 1122, 585);
}

/* 	function called by init function
		purpose: link and activate the helper functions which produce an action's animation
*/
function loop() {
  clearCanvas();
  drawBG();
  drawPlayer();
  requestAnimFrame(loop);
}

/* 	function called by atStart function
		purpose: set up and initiate the process of an action's animation; calls loop function
*/
function init() {
	//import Spritesheet:
  character.src = 'RSPAssets_SpriteSheet_New.png';
	//set variables (change as needed):
	//var num = 1; //<--utility/testing variable, totally unnecessary
	//numFrames = 11;

	player.sx = 0;
	//call loop
	//if (num == 1){
  	loop();
	//reset player for another action
	reset();
}
//Michaela Section End

//Loads the on start function once the page has loaded to start the game automatically
window.onload = atStart();
