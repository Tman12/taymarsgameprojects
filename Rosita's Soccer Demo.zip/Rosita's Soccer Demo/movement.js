var canvas = document.getElementById('canvas'),
    ctx = canvas.getContext('2d'),
    character = new Image(),
    player = {
      x: 0,
      y: 0,
      w: 250,
      h: 250,
      sx: 0,
      sy: 250,
      faceRight: true,
      faceLeft: false,
      counter: 0,
      step: 12,
      nextStep: 0,
      endStep: 96,
      start: {
        rightX: 0,
        leftX: 250,
        y: 250
      }
    },
    key = {
      right: false,
      left: false
    };

var numFrames = 8;

function move(numFrames, right, left) {
  player.faceRight = right;
  player.faceLeft = left;
  if (player.counter === player.endStep) {
    player.sx = 0;
    player.counter = 0;
    player.nextStep = player.step;
  } else if (player.counter === player.nextStep) {
    if (player.sx !== ((numFrames-1) * player.w)) {
      player.sx += player.w;
    }
    //player.sy = yPos;
    player.nextStep += player.step;
  } else if (player.counter === 0){
    player.sx += player.w;
    player.nextStep += player.step;
  }
  player.counter += 1;
}

function reset() {
  //player.sy = player.start.y;
  player.counter = 0;
  player.nextStep = 0;
}

function drawPlayer() {
  if (key.right === true) {
    move(numFrames, true, false);
    player.x += 1;
    if (player.x > canvas.width + player.w + 1) {
      player.x = -player.w;
    }
  }
  if (key.left === true) {
    move(numFrames, false, true);
    player.x -= 1;
    if (player.x < -player.w - 1) {
      player.x = canvas.width + player.w;
    }
  }
  if (key.right === false && player.faceRight === true) {
    player.sx = player.start.rightX;
    reset();
  }
  if (key.left === false && player.faceLeft === true) {
    player.sx = player.start.leftX;
    reset();
  }
  ctx.drawImage(character, player.sx, player.sy, player.w, player.h, player.x, player.y, player.w, player.h);
}

function keyDown(e) {
  if (e.keyCode === 39) {
    key.right = true;
  } else if (e.keyCode === 37) {
    key.left = true;
  }
}

function keyUp(e) {
  if (e.keyCode === 39) {
    key.right = false;
  } else if (e.keyCode === 37) {
    key.left = false;
  }
}

function drawBG() {
  ctx.fillStyle = '#00f';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#0f0';
  ctx.fillRect(0, 250, canvas.width, 15);
}

function clearCanvas() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}

function loop() {
  //clearCanvas();
  drawBG();
  drawPlayer();
  requestAnimFrame(loop);
}

function init() {
  character.src = 'RSPAssets_SpriteSheet_New.png';

  window.addEventListener('keydown', keyDown, false);
  window.addEventListener('keyup', keyUp, false);
  //alert("Here!");
  loop();
}

init();
