CREATE TABLE milkshakeOrders 
(customer_id INT NOT NULL AUTO_INCREMENT,
 customer_name char(50), milkshake char(100), 
 email char(50),homeAddress char(100), 
 phone_num char(20), order_date char(100), PRIMARY KEY(customer_id));