<!DOCTYPE html>
<html>
<style>
a{font-size: 30px;
background-color: Tomato}
</style>
<div>

<a href = "MainMilkshakePage.php">Home</a>

<a href = "ordertable.php"> View Order History</a><br><br><br>



</div>




</html>